#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-collect}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "smoke" ]]; then
  python scripts/run_cave_structured_missing.py --scene-ids 1 --patterns block --methods tucker,ntdpl --target-shape 64,64 --n-iter-max 20 --out-prefix neurips/tables/smoke_cave_structured_missing
  exit 0
fi
if [[ "$MODE" == "collect" ]]; then
  python scripts/prepare_processed_results.py
  exit 0
fi
python scripts/run_cave_structured_missing.py --scene-ids 1,5,10 --patterns block,spectral-band,stripe --methods tucker,ntdpl --rank 24,24,4 --target-shape 512,512 --n-iter-max 300 --out-prefix neurips/tables/cave_structured_missing_subset
