from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.data.tucker import TuckerData
from src.filters.nonlinear import NonlinearFilter
from src.methods.ntdpl import NTDPLDecomposition
from src.methods.tucker import TuckerDecomposition
from src.metrics import val_RMSE
from src.tasks.decompose import DecomposeTask


def _fit(method, dataset) -> float:
    task = DecomposeTask(log_level=0)
    task.setup(dataset, method)
    result = task.run()
    return float(result.eval["RMSE"])


def main() -> int:
    np.random.seed(0)
    dataset = TuckerData(shape=(8, 8, 8), rank=(3, 3, 3), seed=0)
    NonlinearFilter(nonlinear="poly3", alpha=0.2, seed=0, normalize_method="energy", snr_db=None)(dataset)
    tucker = TuckerDecomposition(rank=(3, 3, 3), n_iter_max=12, init="svd", tol=1e-4)
    ntdpl = NTDPLDecomposition(
        rank=(3, 3, 3),
        n_iter_max=12,
        init_n_iter_max=6,
        p_max=3,
        allow_constant_term=True,
        init="tucker",
        solver_variant="optimized",
        stable_beta_update=True,
        beta_update_stage="before_grad",
        use_continuation=True,
        factor_normalize=True,
        lr_core=1e-4,
        lr_factors=3e-4,
        lambda_core=1e-6,
        lambda_factors=1e-6,
        lambda_beta=1e-6,
        beta_update_method="ridge_lstsq",
        beta_update_interval=3,
        random_state=0,
    )
    rmse_tucker = _fit(tucker, dataset)
    rmse_ntdpl = _fit(ntdpl, dataset)
    direct_rmse = val_RMSE(dataset.get(split="eval"), ntdpl.reconstruct())
    print(f"smoke_tucker_rmse={rmse_tucker:.6f}")
    print(f"smoke_ntdpl_rmse={rmse_ntdpl:.6f}")
    print(f"smoke_direct_ntdpl_rmse={direct_rmse:.6f}")
    if not np.isfinite(rmse_ntdpl):
        raise RuntimeError("NTD-PL smoke RMSE is not finite.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
