#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-smoke}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "smoke" ]]; then
  python scripts/smoke_ntdpl.py
  exit 0
fi
python -m experiment linear-consistency run
python -m experiment nonlinear-approx run
python -m experiment postprocess linear-consistency
python -m experiment postprocess nonlinear-approx
python scripts/make_controlled_alpha_strip.py
python scripts/make_controlled_pmax_strip.py
