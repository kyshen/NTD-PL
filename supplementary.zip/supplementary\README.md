# NTD-PL Anonymous Supplementary Code Package

This directory is an anonymized supplementary package for reproducing the main
experiments in the paper. It contains the NTD-PL implementation, baseline
wrappers, experiment drivers, processed result summaries, and figure/table
reconstruction scripts. It does not include raw datasets, raw Hydra logs, model
state dumps, repository metadata, local caches, private paths, tokens, or
author-identifying metadata.

## Environment Setup

```bash
cd supplementary
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r requirements.txt
python -m pip install -e ./experiment
```

On Windows PowerShell, use `.\.venv\Scripts\Activate.ps1`.

## Dataset Preparation

Datasets are not redistributed. Put downloaded datasets under `data/`, or pass
the root path flags exposed by the diagnostic scripts.

| Dataset | Source page | Local path | Use | Shape / protocol |
|---|---|---|---|
| Columbia CAVE multispectral | `https://cave.cs.columbia.edu/old/databases/multispectral/` | `data/CAVE` | CAVE reconstruction/completion | 15 scenes, `512 x 512 x 31`, max-normalized per scene |
| CBSD68 / BSD natural images | `https://www2.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html` or the public CBSD68 PNG split used by image-restoration benchmarks | `data/CBSD68/train` or `data/CBSD68/validation` | non-HSI Link Refresh diagnostic | per image `96 x 96 x 3`, rank `(32,32,3)` |
| CIFAR-10 Python archive | `https://www.cs.toronto.edu/~kriz/cifar.html` | `data/cifar-10-python.tar.gz` or `data/cifar-10-batches-py` | non-HSI diagnostic | per test image `32 x 32 x 3`, rank `(20,20,3)` |
| COIL-100 | `https://www.cs.columbia.edu/CAVE/software/softlib/coil-100.php` | `data/coil-100/coil-100` | non-HSI diagnostic | per object `36 x 48 x 48 x 3`, rank `(8,12,12,2)` |
| smallNORB | `https://cs.nyu.edu/~ylclab/data/norb-v1.0-small/` | `data/smallNORB` | non-HSI diagnostic | per instance `18 x 64 x 64 x 2`, rank `(12,24,24,2)` |
| KTH actions | `https://www.csc.kth.se/cvap/actions/` | script-specific dataset root | video diagnostic | clips `24 x 72 x 96 x 3`, rank `(12,18,18,3)` |
| UCF101 | `https://www.crcv.ucf.edu/data/UCF101.php` | script-specific dataset root | video diagnostic | clips `24 x 72 x 96 x 3`, rank `(12,18,18,3)` |

CAVE can be downloaded with `python scripts/download_cave_dataset.py`.
The CAVE completion masks use random missing entries for the main table
(`rho in {0.1,0.3,0.5,0.7}`, seeds `0,1,2`) and structured block/band/stripe
masks for supplementary checks. Metrics with `*` are computed only on held-out
entries.

## Smoke Test

```bash
bash scripts/run_synthetic.sh smoke
```

With CAVE downloaded:

```bash
bash scripts/run_cave_reconstruction.sh smoke
bash scripts/run_cave_completion.sh smoke
bash scripts/run_cave_structured_completion.sh smoke
```

## Reproducing Main Figures And Tables

Processed summaries used by the paper are included under `processed_results/`.
Restore them and rebuild the main figures:

```bash
python scripts/prepare_processed_results.py
bash scripts/make_main_figures.sh
```

Outputs are written to `neurips/figures/` and `neurips/tables/`. The included
processed CSV/TEX files cover the paper-facing evidence for main Figure 1-4 and
Table 1-3: controlled synthetic summaries, CAVE reconstruction/completion
summaries, and Link Refresh diagnostic summaries.
The `neurips/`, `experiment/outputs/`, and `results/` directories are generated
locally by these commands and are not pre-populated in the clean supplement.

## Re-running Experiments

```bash
bash scripts/run_synthetic.sh full
bash scripts/run_cave_reconstruction.sh full
bash scripts/run_cave_completion.sh full
bash scripts/run_cave_structured_completion.sh full
bash scripts/run_dlink_cave.sh full
bash scripts/run_dlink_nonhsi.sh full
```

Baseline wrappers are in `src/methods/`: `tucker.py`, `cp.py`, `tt.py`,
`tr.py`, and `softimpute.py`. Main CAVE comparisons use matched-rank Tucker;
synthetic controls include CP/TT/TR; low-rank completion includes SoftImpute
where reported.

## Expected Outputs

```text
multirun/<experiment>/              # raw Hydra outputs from re-runs
outputs/<experiment>/               # individual run outputs
experiment/outputs/<experiment>/    # post-processed CSV/TEX summaries
neurips/tables/                     # paper-facing table CSV/TEX files
neurips/figures/                    # regenerated PDF/PNG figures
results/*diagnostic*/               # Link Refresh diagnostic CSVs/plots
```

Raw logs and state dumps are intentionally not included. The included processed
CSV files are sufficient to regenerate the paper-facing figures/tables; raw
outputs can be regenerated with the scripts above.

## Computational Cost Notes

Synthetic smoke tests finish quickly on CPU. Full CAVE reconstruction and
completion sweeps involve 15 scenes, multiple ranks/masks/seeds, and 300
iterations for the main runs; they can take many CPU-hours. Non-HSI diagnostics
are dataset-dependent and require local public datasets, so the package includes
processed diagnostic CSV summaries and exposes smoke/full scripts instead of
redistributing raw data or logs.

## Anonymization Note

This package has been prepared for anonymous review. It excludes `.git/`,
OpenReview-specific files, private tokens/API keys, local caches, local absolute
paths, remote repository URLs, and author-identifying names/emails. Dataset
URLs and citations in the README/scripts refer only to public data sources.
