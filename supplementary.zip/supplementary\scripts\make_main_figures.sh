#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/prepare_processed_results.py
python scripts/make_controlled_alpha_strip.py
python scripts/make_controlled_pmax_strip.py
python scripts/make_cave_reconstruction_capacity_figure.py
python scripts/make_lowrank_rates_figure.py
python scripts/make_cave_link_yield_scatter.py
python scripts/make_nonhsi_dlink_scatter_3domain.py
