from __future__ import annotations

import argparse
import shutil
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _copy_tree_files(src: Path, dst: Path) -> None:
    if not src.exists():
        return
    dst.mkdir(parents=True, exist_ok=True)
    for path in src.rglob("*"):
        if path.is_file():
            out = dst / path.relative_to(src)
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, out)


def main() -> int:
    parser = argparse.ArgumentParser(description="Restore processed CSV/TEX/PDF layout from processed_results.")
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve()
    processed = root / "processed_results"
    _copy_tree_files(processed / "tables", root / "neurips" / "tables")
    _copy_tree_files(processed / "figures", root / "neurips" / "figures")
    _copy_tree_files(processed / "experiment_outputs", root / "experiment" / "outputs")
    mapping = {
        "nonhsi_full68": root / "results" / "nonhsi_dlink_diagnostic" / "20260507_000000_full68",
        "nonhsi_smoke": root / "results" / "nonhsi_dlink_diagnostic" / "smoke_default",
        "kth_full240": root / "results" / "phase1_crossdomain_dlink" / "20260507_120000_kth_full240",
        "ucf101_full240": root / "results" / "phase1_crossdomain_dlink" / "20260507_123000_ucf101_full240",
        "external_tensor_full": root / "results" / "phase1_crossdomain_dlink" / "20260507_000000_full",
    }
    for name, dst in mapping.items():
        _copy_tree_files(processed / "diagnostics" / name, dst)
    print("Restored processed results under neurips/, experiment/outputs/, and results/.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
