#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-collect}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "collect" ]]; then
  python scripts/prepare_processed_results.py
  python scripts/make_cave_link_yield_scatter.py
  exit 0
fi
python scripts/build_ntdpl_diagnostic.py --input-csv experiment/outputs/cave-random-completion/polycal_pairwise_scene_gains.csv --out-prefix neurips/tables/ntdpl_polycal_diagnostic
python scripts/make_cave_link_yield_scatter.py
