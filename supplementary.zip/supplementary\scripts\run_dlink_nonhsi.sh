#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-collect}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "collect" ]]; then
  python scripts/prepare_processed_results.py
  python scripts/make_nonhsi_dlink_scatter_3domain.py
  exit 0
fi
if [[ "$MODE" == "smoke" ]]; then
  python scripts/run_nonhsi_dlink_diagnostic.py --mode smoke --datasets cbsd68,cifar10,coil100,smallnorb --jobs 1 --n-iter-max 20 --tucker-n-iter-max 20 --outdir results/nonhsi_dlink_diagnostic/smoke_reproduced
  exit 0
fi
python scripts/run_nonhsi_dlink_diagnostic.py --mode full --datasets cbsd68,cifar10,coil100,smallnorb --jobs 4 --outdir results/nonhsi_dlink_diagnostic/reproduced_full
python scripts/run_phase1_crossdomain_dlink.py --mode full --datasets kth --jobs 4 --outdir results/phase1_crossdomain_dlink/reproduced_kth_full
python scripts/run_phase1_crossdomain_dlink.py --mode full --datasets ucf101 --jobs 4 --outdir results/phase1_crossdomain_dlink/reproduced_ucf101_full
python scripts/make_nonhsi_dlink_scatter_3domain.py
