#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-collect}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "smoke" ]]; then
  python scripts/run_neurips_lowrank_sweep.py --dataset cave_hsi --item-ids 1 --protocols random --methods tucker,ntdpl --seeds 0 --missing-rates 0.5 --rank 12,12,3 --target-shape 64,64 --n-iter-max 20 --max-parallel 1 --out-prefix neurips/tables/smoke_cave_completion
  exit 0
fi
if [[ "$MODE" == "collect" ]]; then
  python scripts/prepare_processed_results.py
  python scripts/make_lowrank_rates_figure.py
  exit 0
fi
python -m experiment cave-random-completion run
python scripts/run_neurips_lowrank_sweep.py --dataset cave_hsi --item-ids 1-15 --protocols random,block --methods tucker,ntdpl,softimpute --seeds 0,1,2 --missing-rates 0.3,0.5,0.7 --target-shape 128,128 --n-iter-max 180 --max-parallel 1 --out-prefix neurips/tables/lowrank_core_cave_rates
python scripts/make_lowrank_rates_figure.py
