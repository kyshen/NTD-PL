#!/usr/bin/env bash
set -euo pipefail
MODE="${1:-collect}"
cd "$(dirname "$0")/.."
if [[ "$MODE" == "smoke" ]]; then
  python scripts/run_cave_recon_lowrank.py --scene-ids 1 --rank 18,18,3 --n-iter-max 20 --max-parallel 1 --out-prefix neurips/tables/smoke_cave_reconstruction
  exit 0
fi
if [[ "$MODE" == "collect" ]]; then
  python scripts/prepare_processed_results.py
  python scripts/make_cave_reconstruction_capacity_figure.py
  python scripts/make_rank_lift_efficiency_figure.py
  exit 0
fi
python -m experiment cave-representation run
python scripts/run_cave_recon_lowrank.py --scene-ids 1-15 --rank 18,18,3 --n-iter-max 300 --max-parallel 2
python scripts/make_cave_reconstruction_capacity_figure.py
